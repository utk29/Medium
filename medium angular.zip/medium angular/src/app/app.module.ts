import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignupComponent } from './signup/signup.component';
import { SigninComponent } from './signin/signin.component';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FeedComponent } from './feed/feed.component';
import { PnfComponent } from './pnf/pnf.component';
import { AboutusComponent } from './aboutus/aboutus.component';

import { CreateblogComponent } from './createblog/createblog.component';
import { UpdateblogComponent } from './updateblog/updateblog.component';
import { UpdateformComponent } from './updateform/updateform.component';
import { UpdatemodalComponent } from './updateblog/updatemodal/updatemodal.component';
import { UpdateprofileComponent } from './updateprofile/updateprofile.component';
import { SigninforupdateComponent } from './signinforupdate/signinforupdate.component';
import { ReviewComponent } from './review/review.component';
import { FollowersComponent } from './followers/followers.component';






@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    SigninComponent,
    FeedComponent,
    PnfComponent,
    AboutusComponent,
    CreateblogComponent,
    UpdateblogComponent,
    UpdateformComponent,
    UpdatemodalComponent,
    UpdateprofileComponent,
    SigninforupdateComponent,
    ReviewComponent,
    FollowersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,ReactiveFormsModule,HttpClientModule
  ],
  providers: [],

  bootstrap: [AppComponent]
})
export class AppModule { }
