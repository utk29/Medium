import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SearchblogService {

  constructor(private http:HttpClient) { }

  searchBlog(title:string){
    console.log('http://localhost:63884/api/search/'+title);
    return this.http.get('http://localhost:63884/api/search/'+title);
  }
}
