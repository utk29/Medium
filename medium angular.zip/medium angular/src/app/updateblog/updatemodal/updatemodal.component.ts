import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BlogService } from 'src/app/blog.service';

@Component({
  selector: 'app-updatemodal',
  templateUrl: './updatemodal.component.html',
  styleUrls: ['./updatemodal.component.css']
})
export class UpdatemodalComponent implements OnInit {
id:number;
v:any=JSON.parse(sessionStorage.getItem('users'));
uid:string;
data:any;
vs:string=this.v.user_id;
imgurl:string="";
  constructor(private ar:ActivatedRoute, private restapi:BlogService, private route: Router) { 
    
    this.id=ar.snapshot.params["id"];
    this.restapi.getUserBlogUpdate(this.vs, this.id).subscribe(p=>{this.data=p;console.log(this.data);});
    console.log(this.id);
    console.log(this.v.user_id);
  }
onSubmit(content:any){
  
  content.UserId=this.vs;
  content.BlogId=this.id;
  console.log(content);
  this.restapi.putUpdateBlog(this.vs, this.id,content).subscribe(p=>console.log('updated'),e=>console.log(e),()=>{console.log("executed");this.route.navigate(['/updateblog'])});
  
  
}
cancel(){
  this.route.navigate(['/updateblog']);
}

  ngOnInit(): void {
  }

}
