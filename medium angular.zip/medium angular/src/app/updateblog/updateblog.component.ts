import { stringify } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { BlogService } from '../blog.service';

@Component({
  selector: 'app-updateblog',
  templateUrl: './updateblog.component.html',
  styleUrls: ['./updateblog.component.css']
})
export class UpdateblogComponent implements OnInit {
  id: string;
  data: any;
  v: any = JSON.parse(sessionStorage.getItem('users'));
  loggedinuser:string="";
  constructor(private restapi: BlogService, private ar: ActivatedRoute, private route: Router) {
    this.id = this.v.user_id;
    console.log(this.v);
    restapi.getUserBlogs(this.id).subscribe(p => { this.data = p; console.log(this.data) });
    if (sessionStorage.getItem('users')) {
      this.loggedinuser = JSON.parse(sessionStorage.getItem('users'));
      console.log(this.loggedinuser);
    }
  }
  jump(bid:number) {
    this.route.navigate(['/updateblog/'+bid]);
  }
  uid: string;
  a: any;
  content: any;
  del(bid: number) {
    if (confirm('Are you sure ?')) {
      this.uid = this.v.user_id;
      console.log(bid);
      this.restapi.deleteUserBlog(this.uid, bid).subscribe(a => { this.content = a; console.log(this.content);});
      window.location.reload();
    }
    else{
      this.route.navigate(['/updateblog']);
      window.location.reload();
    }
  }
 

  ngOnInit(): void {
    
  }

}
