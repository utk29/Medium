import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ReviewService } from '../review.service';

@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {
  user:any = JSON.parse(sessionStorage.getItem('users'));
  oldreview:any;
  constructor(private route: Router, private reviewapi:ReviewService) { 
    this.reviewapi.getReviewbyId(this.user.user_id).subscribe(r=>{this.oldreview=r;console.log(this.oldreview)});
  }
  
onSubmit(data:any)
{
  data.UserId=this.user.user_id;
  data.FirstName=this.user.first_name;
  data.LastName=this.user.last_name;
  data.UserImage=this.user.photo_filename;
  data.UserBio=this.user.bio;
  if(this.oldreview==null)
  {
    this.reviewapi.postReview(data).subscribe(p=>console.log(p));
    alert("Your review has been submitted");
    this.route.navigate(['/feed']);
  }
  else{
    this.reviewapi.putReview(data.UserId,data).subscribe(p=>console.log(p));
    alert("Your review has been updated");
    this.route.navigate(['/feed']);
  }
  
}
cancel(){
this.route.navigate(['/feed']);
}
  ngOnInit(): void {
  }

}
