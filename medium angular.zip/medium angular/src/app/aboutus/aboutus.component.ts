import { Component, OnInit } from '@angular/core';
import { ReviewService } from '../review.service';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent implements OnInit {
reviews:any;
  constructor(private reviewapi:ReviewService) {
    this.reviewapi.getReviews().subscribe(r=>{console.log(r);this.reviews=r});
   }

  ngOnInit(): void {
  }

}
