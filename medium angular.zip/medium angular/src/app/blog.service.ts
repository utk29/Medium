import { Injectable } from '@angular/core';
import {HttpClient, HttpClientModule} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class BlogService {

  
  constructor(private http:HttpClient) { }
  getuserpostdetails(id:String){
    return this.http.get("http://localhost:63884/api/blogs/"+id);
    
  }

  

  postBlog(blog:any)
  {
    return this.http.post("http://localhost:63884/api/blogs", blog);
  }

  getUserBlogs(id:string)
  {
    return this.http.get("http://localhost:63884/api/Updatefeed/" + id);
  }

  deleteUserBlog(u:string, b:number)
  {
    return this.http.delete('http://localhost:63884/api/blogs/delete?uid='+ u+ "&bid="+ b);
  }

  getUserBlogUpdate(u:string, b:number)
  {
    return this.http.get('http://localhost:63884/api/blogs/delete?uid='+ u+ "&bid="+ b);
  }

  putUpdateBlog(u:string, b:number, data:any)
  {
    return this.http.put('http://localhost:63884/api/blogs/put?id='+ u+ "&bid="+ b, data);
  }

}

//return this.http.get("http://localhost:52848/api/Userpostdetails/?UserId:"+UserId+"/?pass:"+password);