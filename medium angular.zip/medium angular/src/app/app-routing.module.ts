import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { CreateblogComponent } from './createblog/createblog.component';

import { FeedComponent } from './feed/feed.component';
import { FollowersComponent } from './followers/followers.component';
import { PnfComponent } from './pnf/pnf.component';
import { ReviewComponent } from './review/review.component';
import { SigninComponent } from './signin/signin.component';
import { SigninforupdateComponent } from './signinforupdate/signinforupdate.component';
import { SignupComponent } from './signup/signup.component';
import { UpdateblogComponent } from './updateblog/updateblog.component';
import { UpdatemodalComponent } from './updateblog/updatemodal/updatemodal.component';
import { UpdateformComponent } from './updateform/updateform.component';
import { UpdateprofileComponent } from './updateprofile/updateprofile.component';


const routes: Routes = [
  {path:'aboutus', component: AboutusComponent},
  {path:'signup', component: SignupComponent},
  {path:'signin', component: SigninComponent},
  {path:'feed', component:FeedComponent },
  {path: 'createblog', component: CreateblogComponent},
  {path: 'updateblog', component: UpdateblogComponent},
  {path: 'updateblog/:id', component: UpdatemodalComponent},
  {path:'updateform', component:UpdateformComponent},
  {path:'updateprofile', component:UpdateprofileComponent},
  {path: 'signinforupdate', component: SigninforupdateComponent},
  {path:'review', component:ReviewComponent},
  {path:'followers', component:FollowersComponent},
  {​​​​​​​path:'',redirectTo:'aboutus',pathMatch:'full'}​​​​​​​, //redirect to app root
  {​​​​​​​path:'**',component:PnfComponent}​​​​​​​,
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
