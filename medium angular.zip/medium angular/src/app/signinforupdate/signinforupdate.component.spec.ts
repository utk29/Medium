import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SigninforupdateComponent } from './signinforupdate.component';

describe('SigninforupdateComponent', () => {
  let component: SigninforupdateComponent;
  let fixture: ComponentFixture<SigninforupdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SigninforupdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SigninforupdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
