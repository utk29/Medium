import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Md5 } from 'ts-md5';
import { DataserviceService } from '../dataservice.service';
import { RegistrationService } from '../registration.service';

@Component({
  selector: 'app-signinforupdate',
  templateUrl: './signinforupdate.component.html',
  styleUrls: ['./signinforupdate.component.css']
})
export class SigninforupdateComponent implements OnInit {

  posts: any;
  str: string;
  signinforupdateform:FormGroup;
  userDetails: any;
  token:string="";
  msg:boolean=false;
  constructor(private fb: FormBuilder, private restapi: RegistrationService, private route: Router, private data:DataserviceService) { 
    this.signinforupdateform = this.fb.group({
      user_id: ["",Validators.compose([Validators.required ])],
      pass: ["",Validators.compose([Validators.required])],
      
    })
  }
  onSubmit(data: any) {
    const md5= new Md5();
    console.log(data);
    data.pass=md5.appendStr(data.pass).end();
    this.restapi.getUser(data.user_id, data.pass).subscribe(p=>{console.log(p);this.userDetails=p;
      if(this.userDetails !=null)
      {
         sessionStorage.setItem('users', JSON.stringify(this.userDetails));
         this.data.token=this.userDetails.user_id;
         
      }
      if(sessionStorage.getItem('users')!=null)
      {
         this.token=data.user_id;
         this.msg=true;
         this.route.navigate(['/updateprofile']);
         
      }
      else{
        this.token="Not Found";
              }
    })
    
    }

    closeAlert(){
      this.msg=false;
    }
  
    

  ngOnInit(): void {

  }
  
  match(data: any) {

  }

}
