import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LikesService {

  constructor(private http:HttpClient) { }
  postLike(u:string, b:number, l:string, data:any)
  {
    return this.http.post('http://localhost:63884/api/blog_likes/post?uid='+u+"&bid="+b+"&lid="+l, data);
  }
   user= JSON.parse(sessionStorage.getItem('users'));
getLikes(){
  
    return this.http.get('http://localhost:63884/api/blog_likes/'+this.user.user_id);
}
deleteLikes(uid:string, bid:number){
  return this.http.delete('http://localhost:63884/api/blog_likes/delete?uid='+uid+"&bid="+bid+"&lid="+this.user.user_id);
}
}
