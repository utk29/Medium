import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Md5 } from 'ts-md5';
import { DataserviceService } from '../dataservice.service';
import { RegistrationService } from '../registration.service';

@Component({
  selector: 'app-updateprofile',
  templateUrl: './updateprofile.component.html',
  styleUrls: ['./updateprofile.component.css']
})
export class UpdateprofileComponent implements OnInit {
  data:any=JSON.parse(sessionStorage.getItem('users'));
  msg:boolean= false;
  constructor(private fb: FormBuilder, public restapi: RegistrationService, private route:Router) {
   //console.log(this.data);
    this.updateprofileform = this.fb.group({
      user_id: ["",Validators.compose([Validators.required ])],
      first_name: ["",Validators.compose([Validators.required ,Validators.pattern('[a-z A-Z]+')])],
      middle_name: ["",Validators.compose([Validators.pattern('[a-z A-Z]+')])],
      last_name: ["",Validators.compose([Validators.required ,Validators.pattern('[a-z A-Z]+')])],
      phone_number: ["",Validators.compose([Validators.required])],
      email_id: ["",Validators.compose([Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")])],
      gender: [],
      date_of_birth:["",Validators.compose([Validators.required]) ],
      pass: ["",Validators.compose([Validators.required])],
      cpass:[],
      photo_filename: [],
      bio:[],
      created_at: []
    })


  }
uidold:string= this.data.user_id;
  onSubmit(content: any) {
    if(content.pass==null)
    {
      alert("Password can't be empty");
    }
    else
    {
    const md5= new Md5();
    content.pass=md5.appendStr(content.pass).end();
    
    content.user_id=this.uidold;
    
     this.msg=true;
      this.restapi.updateUser(this.uidold, content).subscribe(p=>
        {
          //sessionStorage.removeItem('users');
          sessionStorage.setItem('users',JSON.stringify(content));
          this.route.navigate(['/feed']);
        }); 
  }
  
  }
  
  updateprofileform: FormGroup;
  pass:string;
  cpass:string;
  ngDoCheck(){
    
    if(this.pass==this.cpass)
    {

      console.log("same");
    }
    else{
      console.log("notsame");
    }
  }
  jump(){
    console.log("hi");
    this.route.navigate(['/feed']);
  }
cancel(){
this.route.navigate(['/feed']);
}
  
  
  ngOnInit(): void {
  }

}
