import { Component, OnInit } from '@angular/core';
import { FollowersService } from '../followers.service';
import { RegistrationService } from '../registration.service';

@Component({
  selector: 'app-followers',
  templateUrl: './followers.component.html',
  styleUrls: ['./followers.component.css']
})
export class FollowersComponent implements OnInit {
userdata:any;
follow:any;
followflag: boolean[];
data : any = JSON.parse(sessionStorage.getItem('users'));
  constructor(private registrationapi:RegistrationService, private followersapi:FollowersService) { 
    this.registrationapi.getData().subscribe(d=>{this.userdata=d;console.log(this.userdata);
      this.followersapi.getFollowers(this.data.user_id).subscribe(z=>{console.log(z);
      this.follow = z;
      for (let i = 0; i < this.userdata.length; i++) {
        
        this.userdata[i].followed = 0;
        
        for (let j = 0; j < this.follow.length; j++) {
          if (this.userdata[i].user_id == this.follow[j].FollowingId) {
            this.userdata[i].followed = 1;
          }
        }

      }
    });
    });
  }
  
  f:any={​​"UserID":null, "FollowingId":null}​​;
  followuser(followingid:string, idx:number){
    this.userdata[idx].followed = 1;
    this.f.UserId=this.data.user_id,
    this.f.FollowingId=followingid;
    this.followersapi.postFollowers(this.f).subscribe(d=>console.log(d));
  }

  unfollowuser(id:string, idx:number){
    this.userdata[idx].followed = 0;
    this.followersapi.deleteFollowers(this.data.user_id,id).subscribe(d=>console.log(d));
  }

  
onSearch(datafollower:any){
  console.log(datafollower);
  this.registrationapi.searchFollower(datafollower.search).subscribe(f=>{this.userdata=f;console.log(this.userdata)});
}
  ngOnInit(): void {
  }

}
