
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


import { BlogService } from '../blog.service';
import { LikesService } from '../likes.service';
import { RegistrationService } from '../registration.service';
import { ReviewService } from '../review.service';
import { SearchblogService } from '../searchblog.service';


@Component({
  selector: 'app-feed',
  templateUrl: './feed.component.html',
  styleUrls: ['./feed.component.css']
})
export class FeedComponent implements OnInit {
  id: any;
  data: any;
  UserId: string;
  pass: string;
  loggedinuser: string = "";
  userDetails: any;
  likes: any;
  reviews:any;
  newdata :any= JSON.parse(sessionStorage.getItem('users'));
  constructor(private ar: ActivatedRoute, private reviewapi:ReviewService,private restapi: BlogService, private restapi3: SearchblogService, restapi1: RegistrationService, private route: Router, private restapi2: LikesService) {
    this.id = ar.snapshot.params["id"];
    this.UserId = ar.snapshot.params["UserId"];
    this.pass = ar.snapshot.params["pass"];

    //console.log(this.UserId);
    restapi.getuserpostdetails(this.newdata.user_id).subscribe(p => {
      this.data = p; ;
    
      this.restapi2.getLikes().subscribe(l => {
        console.log(l); this.likes = l;
        for (let i = 0; i < this.data.length; i++) {
          
          this.data[i].liked = 0;
          this.data[i].readmore = true;
          for (let j = 0; j < this.likes.length; j++) {
            if (this.data[i].UserId == this.likes[j].UserId && this.data[i].BlogId == this.likes[j].BlogId) {
              this.data[i].liked = 1;
            }
          }

        } 
      });

    });
    if (sessionStorage.getItem('users')) {
      this.loggedinuser = JSON.parse(sessionStorage.getItem('users'));
      //console.log(this.loggedinuser);
    }
   
    
  }
  clearSession() {
    sessionStorage.clear();
  }

  loginAgain() {
    if (confirm("To update your profile you need to login again. Are you sure you want to continue?")) {
      this.route.navigate(['/signinforupdate']);
      sessionStorage.clear();
    }
  }
  likeflag: boolean[];
  data2: any;
  userdetails: any = JSON.parse(sessionStorage.getItem('users'));
  likeupdate(uid: string, bid: number, idx: number) {
    console.log(uid);
    console.log(bid, this.userdetails.user_id);
    this.restapi2.postLike(uid, bid, this.userdetails.user_id, this.data2).subscribe(s => { console.log(s); this.data[idx].likes++ });
    this.data[idx].liked = 1;
    //window.location.reload();
  }
  dislikeupdate(uid: string, bid: number, idx: number) {
    this.restapi2.deleteLikes(uid, bid).subscribe(d => { console.log(d); this.data[idx].likes-- });
    this.data[idx].liked = 0;
  }
  onSearch(searchdata: any) {
    console.log(searchdata);
    this.restapi3.searchBlog(searchdata.search).subscribe(s => {
      this.data = s;

      this.restapi2.getLikes().subscribe(l => {
        console.log(l); this.likes = l;
        for (let i = 0; i < this.data.length; i++) {
          this.data[i].liked = 0;
          for (let j = 0; j < this.likes.length; j++) {
            if (this.data[i].UserId == this.likes[j].UserId && this.data[i].BlogId == this.likes[j].BlogId) {
              this.data[i].liked = 1;
            }
          }

        } console.log(this.data);
      });

    });
  }
 
readMore(idx:number){
  this.data[idx].readmore=false;
}

readLess(idx:number){
  this.data[idx].readmore=true;
}

  
  count: number = 0;
  ngOnInit(): void {
    this.restapi.getuserpostdetails(this.newdata.user_id).subscribe(p => {
      this.data = p; console.log(this.data);
      let user = JSON.parse(sessionStorage.getItem('users'));
      
      for (let i = 0; i < this.data.length; i++) {
        
        if (this.data[i].UserId == user.user_id) {
          this.count++;
        }
      }
      
    })
  }

}
