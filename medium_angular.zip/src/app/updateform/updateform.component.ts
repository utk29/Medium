import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BlogService } from '../blog.service';

@Component({
  selector: 'app-updateform',
  templateUrl: './updateform.component.html',
  styleUrls: ['./updateform.component.css']
})
export class UpdateformComponent implements OnInit {

  constructor(private ar:ActivatedRoute, private restapi:BlogService) {

   }

   onSubmit(data:any){}

  ngOnInit(): void {
  }

}
