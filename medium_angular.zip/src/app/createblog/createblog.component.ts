import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BlogService } from '../blog.service';

@Component({
  selector: 'app-createblog',
  templateUrl: './createblog.component.html',
  styleUrls: ['./createblog.component.css']
})
export class CreateblogComponent implements OnInit {
imgurl:string="";
  constructor(private blogapi: BlogService, private route:Router) { }
  v:any=JSON.parse(sessionStorage.getItem('users'));
  onSubmit(data:any){
    //console.log(this.v);
    data.UserId=this.v.user_id;
    //console.log(data);
    this.blogapi.postBlog(data).subscribe(s=>console.log(s));
    this.route.navigate(['/feed']);
}
cancel(){
  this.route.navigate(['/feed']);
}
  ngOnInit(): void {
  }

}
