import { FormBuilder, FormGroup , Validators} from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataserviceService } from '../dataservice.service';
import { Md5 } from 'ts-md5';
import { RegistrationService } from '../registration.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
  posts: any;
  str: string;
  signinform:FormGroup;
  userDetails: any;
  token:string="";
  msg:boolean=false;
  constructor(private fb: FormBuilder, private restapi: RegistrationService, private route: Router, private data:DataserviceService) { 
    this.signinform = this.fb.group({
      user_id: ["",Validators.compose([Validators.required ])],
      pass: ["",Validators.compose([Validators.required])],
      
    })
  }

  onSubmit(data: any) {
    const md5= new Md5();
    //console.log(data);
    data.pass=md5.appendStr(data.pass).end();
    this.restapi.getUser(data.user_id, data.pass).subscribe(p=>{this.userDetails=p;
      if(this.userDetails !=null)
      {
         sessionStorage.setItem('users', JSON.stringify(this.userDetails));
         this.data.token=this.userDetails.user_id;
         
      }
      if(sessionStorage.getItem('users')!=null)
      {
         this.token=data.user_id;
         this.msg=true;
         this.route.navigate(['/feed']);
         
      }
      else{
        this.token="Not Found";
              }
    }) 
    }

    closeAlert(){
      this.msg=false;
    }
  
    

  ngOnInit(): void {

  }
  
  match(data: any) {

  }
}
