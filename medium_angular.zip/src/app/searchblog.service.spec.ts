import { TestBed } from '@angular/core/testing';

import { SearchblogService } from './searchblog.service';

describe('SearchblogService', () => {
  let service: SearchblogService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SearchblogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
