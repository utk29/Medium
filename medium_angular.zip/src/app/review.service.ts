import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ReviewService {

  constructor(private http:HttpClient) { }

  getReviews(){
    return this.http.get("http://localhost:63884/api/reviews");
  }

  getReviewbyId(id:string){
    return this.http.get("http://localhost:63884/api/reviews/"+id);
  }

  postReview(data:any){console.log(data);
    return this.http.post("http://localhost:63884/api/reviews",data);
  }

  putReview(id:string, data:any)
  {
    return this.http.put("http://localhost:63884/api/reviews/put?id="+id, data);
  }
}
