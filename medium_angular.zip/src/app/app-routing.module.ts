import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { CreateblogComponent } from './createblog/createblog.component';

import { FeedComponent } from './feed/feed.component';
import { FollowersComponent } from './followers/followers.component';
import { LoginGuard } from './login.guard';
import { PnfComponent } from './pnf/pnf.component';
import { ReviewComponent } from './review/review.component';
import { SigninComponent } from './signin/signin.component';
import { SigninforupdateComponent } from './signinforupdate/signinforupdate.component';
import { SignupComponent } from './signup/signup.component';
import { UpdateblogComponent } from './updateblog/updateblog.component';
import { UpdatemodalComponent } from './updateblog/updatemodal/updatemodal.component';
import { UpdateformComponent } from './updateform/updateform.component';
import { UpdateprofileComponent } from './updateprofile/updateprofile.component';


const routes: Routes = [
  {path:'aboutus', component: AboutusComponent},
  {path:'signup', component: SignupComponent},
  {path:'signin', component: SigninComponent},
  {path:'feed', component:FeedComponent, canActivate:[LoginGuard] },
  {path: 'createblog', component: CreateblogComponent, canActivate:[LoginGuard]},
  {path: 'updateblog', component: UpdateblogComponent, canActivate:[LoginGuard]},
  {path: 'updateblog/:id', component: UpdatemodalComponent, canActivate:[LoginGuard]},
  {path:'updateform', component:UpdateformComponent},
  {path:'updateprofile', component:UpdateprofileComponent},
  {path: 'signinforupdate', component: SigninforupdateComponent},
  {path:'review', component:ReviewComponent, canActivate:[LoginGuard]},
  {path:'followers', component:FollowersComponent},
  {​​​​​​​path:'',redirectTo:'aboutus',pathMatch:'full'}​​​​​​​, //redirect to app root
  {​​​​​​​path:'**',component:PnfComponent}​​​​​​​,
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
