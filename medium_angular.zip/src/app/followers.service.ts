import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FollowersService {

  constructor(private http:HttpClient) { }
  getFollowers(uid:string, fid:string="1"){
    return this.http.get("http://localhost:63884/api/followers/get?uid="+uid+"&fid="+fid);
  }

  postFollowers(follow:any)
  {
    return this.http.post("http://localhost:63884/api/followers",follow);
  }

  deleteFollowers(userid:string, followingid:string){
    return this.http.delete("http://localhost:63884/api/followers/delete?uid="+userid+"&fid="+followingid);
  }
}
