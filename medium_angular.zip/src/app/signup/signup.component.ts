import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup , Validators} from '@angular/forms';
import { Md5 } from 'ts-md5';
import { RegistrationService } from '../registration.service';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
  providers: [RegistrationService]
})

export class SignupComponent implements OnInit {
  msg:boolean;
  imgurl:string="";
  constructor(private fb: FormBuilder, public restapi: RegistrationService) {
   
    this.signupform = this.fb.group({
      user_id: ["",Validators.compose([Validators.required ])],
      first_name: ["",Validators.compose([Validators.required ,Validators.pattern('[a-z A-Z]+')])],
      middle_name: ["",Validators.compose([Validators.pattern('[a-z A-Z]+')])],
      last_name: ["",Validators.compose([Validators.required ,Validators.pattern('[a-z A-Z]+')])],
      phone_number: ["",Validators.compose([Validators.required])],
      email_id: ["",Validators.compose([Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")])],
      gender: [],
      date_of_birth:["",Validators.compose([Validators.required]) ],
      pass: ["",Validators.compose([Validators.required])],
      cpass:[""],
      photo_filename: [],
      bio:[],
      created_at: []
    })
  }
  signupform: FormGroup;

  ngOnInit(): void {

  }
  idvalidator(data):object{              
      
    let minlength=4,maxlength=8;
    if(!data.value)         
   {​​​​​​​
       return null    
   }​​​​​​​
    let id=data.length;
    if(id>=minlength && id<=maxlength){​​​​​​​
        return null;            
    }​​​​​​​
    else{​​​​​​​
        return{​​​​​​​sid:{​​​​​​​'min':minlength,'max':maxlength}​​​​​​​}​​​​​​​ ;          }​​​​​​​
}​​​​​​​
​​​
 
  onSubmit(data: any) {
    const md5= new Md5();
   
    data.pass=md5.appendStr(data.pass).end();
    //console.log(data);
    this.restapi.postData(data).subscribe(s => {this.msg=true; });
    
    //console.log(data);
    this.clearForm();

  }
  available?:boolean=null;
  flag:boolean=false;
  userid:string="";
  checkuserid(id:string){
    this.flag=true;
    //console.log(id);
    this.restapi.getDatabyid(id).subscribe(q=>{
    this.available=false;
    },e=>{this.available=true;this.userid=id});
  }

  pass:string;
  cpass:string;
  Checkpass(){
    console.log(this.pass);
    console.log(this.cpass);
    if(this.pass==this.cpass)
    {

      console.log("same");
    }
    else{
      console.log("notsame");
    }
  }
  closeAlert(){
    this.msg=false;
  }
  clearForm() {
    this.signupform = this.fb.group({
      user_id: [],
      first_name: [],
      middle_name: [],
      last_name: [],
      phone_number: [],
      email_id: [],
      gender: [],
      date_of_birth:[],
      pass: [],cpass:[],
      photo_filename: [],
      bio:[],
      created_at: [],
      
    })
    this.imgurl="";
  }
}



