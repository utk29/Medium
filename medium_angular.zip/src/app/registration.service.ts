import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {
  url: string = "http://localhost:63884/api/registrations";

  constructor(private http: HttpClient) { }
  getData() {
    return this.http.get(this.url);
  }

  getDatabyid(id:string)
  {
    return this.http.get("http://localhost:63884/api/registrations/"+id);
  }

  searchFollower(s:string)
  {
    return this.http.get("http://localhost:63884/api/SearchFollower/"+s);
  }

  postData(user: any) {

    return this.http.post(this.url, user);

  }
  getUser(userId: string, password: string) {
    return this.http.get('http://localhost:63884/api/registrations/Login?username=' + userId + "&password=" + password);
  }

  updateUser(id: string, user: any)
  {
    return this.http.put('http://localhost:63884/api/registrations/put?id=' + id, user);
 }    
    
    
    
    
    
  
  
}
